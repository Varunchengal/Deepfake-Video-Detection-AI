# detector_utils.py - Frame Extraction & Computer Vision Helpers

import cv2
import numpy as np


def _load_face_cascade():
    """
    Load OpenCV's Haar face detector when the installed cv2 build supports it.
    Some OpenCV builds/packages may not expose CascadeClassifier; in that
    case the app safely uses the centre-crop fallback.
    """
    cascade_class = getattr(cv2, "CascadeClassifier", None)
    data = getattr(cv2, "data", None)
    haar_dir = getattr(data, "haarcascades", None) if data is not None else None

    if cascade_class is None or not haar_dir:
        return None

    try:
        cascade_path = haar_dir + "haarcascade_frontalface_default.xml"
        cascade = cascade_class(cascade_path)
        if cascade.empty():
            return None
        return cascade
    except (AttributeError, cv2.error, OSError, TypeError):
        return None


_FACE_CASCADE = _load_face_cascade()


def extract_face_region(frame):
    """
    Extract the largest frontal face if Haar detection is available.
    Otherwise, return a centre crop.

    Input: OpenCV BGR frame.
    Output: RGB uint8 crop. Resizing/normalization remain in the model transform.
    """
    if frame is None or not isinstance(frame, np.ndarray) or frame.size == 0:
        raise ValueError("extract_face_region() received an empty or invalid frame.")

    if frame.ndim != 3 or frame.shape[2] != 3:
        raise ValueError("Expected a 3-channel BGR image from OpenCV.")

    height, width = frame.shape[:2]
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Try face detection only if the installed OpenCV build supports it.
    if _FACE_CASCADE is not None:
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = _FACE_CASCADE.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(40, 40),
                flags=cv2.CASCADE_SCALE_IMAGE,
            )

            if len(faces) > 0:
                x, y, face_width, face_height = max(
                    faces, key=lambda box: int(box[2]) * int(box[3])
                )

                pad_x = int(face_width * 0.25)
                pad_y = int(face_height * 0.25)

                x1 = max(0, int(x) - pad_x)
                y1 = max(0, int(y) - pad_y)
                x2 = min(width, int(x + face_width) + pad_x)
                y2 = min(height, int(y + face_height) + pad_y)

                face_crop = rgb_frame[y1:y2, x1:x2]
                if face_crop.size > 0:
                    return face_crop
        except (AttributeError, cv2.error, TypeError, ValueError):
            # Fall through to the safe crop if detector APIs are unavailable.
            pass

    # Fallback crop. Kept compatible with the original 60% centre-region logic.
    crop_h = max(1, int(height * 0.6))
    crop_w = max(1, int(width * 0.6))
    start_y = max(0, (height - crop_h) // 2)
    start_x = max(0, (width - crop_w) // 2)

    return rgb_frame[start_y:start_y + crop_h, start_x:start_x + crop_w]


def analyze_texture_artifacts(image_np):
    """
    Return Laplacian variance as a basic sharpness/texture indicator.
    This is only an auxiliary metric, not a standalone deepfake detector.

    Input: RGB or grayscale NumPy image.
    Output: float.
    """
    if image_np is None or not isinstance(image_np, np.ndarray) or image_np.size == 0:
        raise ValueError("analyze_texture_artifacts() received an empty or invalid image.")

    if image_np.ndim == 2:
        gray = image_np
    elif image_np.ndim == 3 and image_np.shape[2] == 3:
        # extract_face_region() returns RGB.
        gray = cv2.cvtColor(image_np, cv2.COLOR_RGB2GRAY)
    else:
        raise ValueError("Expected a grayscale or 3-channel RGB image.")

    return float(cv2.Laplacian(gray, cv2.CV_64F).var())
