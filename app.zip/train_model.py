# train_model.py
# CPU-friendly ResNet18 fine-tuning for a small Real/Fake dataset.
#
# Required folder structure:
# dataset/
#   train/
#     real/
#     fake/
#   val/
#     real/
#     fake/

import copy
import os
import random
import time

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, models, transforms


# --------------------------------------------------
# 1. CONFIGURATION FOR A SMALL DATASET + CPU
# --------------------------------------------------

DATA_DIR = "dataset"
MODEL_DIR = "models"
MODEL_PATH = os.path.join(MODEL_DIR, "deepfake_model.pth")

MAX_EPOCHS = 15
BATCH_SIZE = 8
EARLY_STOPPING_PATIENCE = 4
NUM_WORKERS = 0  # Recommended safe setting on Windows

# Separate learning rates: smaller for pretrained features,
# larger for the newly-created classification layer.
FEATURES_LR = 0.00003
CLASSIFIER_LR = 0.0003
WEIGHT_DECAY = 0.0005

SEED = 42
DEVICE = torch.device("cpu")  # User has no NVIDIA GPU.


# --------------------------------------------------
# 2. REPRODUCIBILITY
# --------------------------------------------------

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))


# --------------------------------------------------
# 3. DATASET CLASS
#    Force label 0 = REAL and label 1 = FAKE.
#    This matches app.py's probabilities[0][1] fake score.
# --------------------------------------------------

class RealFakeImageFolder(datasets.ImageFolder):
    def find_classes(self, directory):
        folder_names = [
            name
            for name in os.listdir(directory)
            if os.path.isdir(os.path.join(directory, name))
        ]

        name_lookup = {name.lower(): name for name in folder_names}

        if "real" not in name_lookup or "fake" not in name_lookup:
            raise FileNotFoundError(
                f"Expected 'real' and 'fake' folders in {directory}. "
                f"Found folders: {folder_names}"
            )

        real_name = name_lookup["real"]
        fake_name = name_lookup["fake"]

        return [real_name, fake_name], {
            real_name: 0,
            fake_name: 1,
        }


# --------------------------------------------------
# 4. TRANSFORMS
# --------------------------------------------------

data_transforms = {
    "train": transforms.Compose(
        [
            transforms.Resize((240, 240)),
            transforms.RandomCrop((224, 224)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.ColorJitter(
                brightness=0.08,
                contrast=0.08,
                saturation=0.05,
                hue=0.01,
            ),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ]
    ),
    "val": transforms.Compose(
        [
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ]
    ),
}


# --------------------------------------------------
# 5. LOAD DATASET
# --------------------------------------------------

print("=" * 60)
print("DEEPFAKE DETECTION - SMALL DATASET CPU TRAINING")
print("=" * 60)
print(f"Device: {DEVICE}")
print(f"Maximum epochs: {MAX_EPOCHS}")
print(f"Batch size: {BATCH_SIZE}")

try:
    image_datasets = {
        split: RealFakeImageFolder(
            os.path.join(DATA_DIR, split),
            data_transforms[split],
        )
        for split in ["train", "val"]
    }

    train_dataset = image_datasets["train"]
    val_dataset = image_datasets["val"]

    if train_dataset.class_to_idx != val_dataset.class_to_idx:
        raise ValueError(
            "Train and validation class mappings do not match."
        )

    if len(train_dataset) == 0 or len(val_dataset) == 0:
        raise ValueError("Training or validation dataset is empty.")

    train_counts = [0, 0]
    for _, label in train_dataset.samples:
        train_counts[label] += 1

    val_counts = [0, 0]
    for _, label in val_dataset.samples:
        val_counts[label] += 1

    if min(train_counts) == 0 or min(val_counts) == 0:
        raise ValueError(
            "Both real and fake images must exist in train and val folders."
        )

    dataloaders = {
        "train": DataLoader(
            train_dataset,
            batch_size=BATCH_SIZE,
            shuffle=True,
            num_workers=NUM_WORKERS,
            pin_memory=False,
        ),
        "val": DataLoader(
            val_dataset,
            batch_size=BATCH_SIZE,
            shuffle=False,
            num_workers=NUM_WORKERS,
            pin_memory=False,
        ),
    }

    dataset_sizes = {
        "train": len(train_dataset),
        "val": len(val_dataset),
    }

    print("\nDataset loaded successfully.")
    print("Class mapping:", train_dataset.class_to_idx)
    print(
        f"Train: {dataset_sizes['train']} images "
        f"(Real: {train_counts[0]}, Fake: {train_counts[1]})"
    )
    print(
        f"Validation: {dataset_sizes['val']} images "
        f"(Real: {val_counts[0]}, Fake: {val_counts[1]})"
    )

except Exception as error:
    print("\nDATASET ERROR:")
    print(error)
    raise SystemExit(1)


# --------------------------------------------------
# 6. LOAD RESNET18 AND FINE-TUNE LAYER4 + FC
# --------------------------------------------------

print("\nLoading pretrained ResNet18...")

weights = models.ResNet18_Weights.DEFAULT
model = models.resnet18(weights=weights)

# Freeze the full pretrained network first.
for parameter in model.parameters():
    parameter.requires_grad = False

# Fine-tune only the last residual block.
for parameter in model.layer4.parameters():
    parameter.requires_grad = True

# Replace the classification head for two classes.
model.fc = nn.Linear(model.fc.in_features, 2)
model = model.to(DEVICE)


# --------------------------------------------------
# 7. LOSS, OPTIMIZER AND SCHEDULER
# --------------------------------------------------

total_train = sum(train_counts)

class_weights = torch.tensor(
    [
        total_train / (2.0 * train_counts[0]),
        total_train / (2.0 * train_counts[1]),
    ],
    dtype=torch.float32,
    device=DEVICE,
)

criterion = nn.CrossEntropyLoss(weight=class_weights)

optimizer = optim.AdamW(
    [
        {
            "params": model.layer4.parameters(),
            "lr": FEATURES_LR,
        },
        {
            "params": model.fc.parameters(),
            "lr": CLASSIFIER_LR,
        },
    ],
    weight_decay=WEIGHT_DECAY,
)

scheduler = optim.lr_scheduler.ReduceLROnPlateau(
    optimizer,
    mode="min",
    factor=0.5,
    patience=1,
)


# --------------------------------------------------
# 8. TRAINING LOOP + EARLY STOPPING
# --------------------------------------------------

best_val_loss = float("inf")
best_val_accuracy = 0.0
best_model_weights = copy.deepcopy(model.state_dict())
epochs_without_improvement = 0

os.makedirs(MODEL_DIR, exist_ok=True)

start_time = time.time()

print("\nTraining started...")
print("-" * 60)

for epoch in range(MAX_EPOCHS):
    print(f"\nEpoch {epoch + 1}/{MAX_EPOCHS}")

    for phase in ["train", "val"]:
        if phase == "train":
            model.train()
        else:
            model.eval()

        running_loss = 0.0
        running_corrects = 0

        for inputs, labels in dataloaders[phase]:
            inputs = inputs.to(DEVICE)
            labels = labels.to(DEVICE)

            optimizer.zero_grad(set_to_none=True)

            with torch.set_grad_enabled(phase == "train"):
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                predictions = torch.argmax(outputs, dim=1)

                if phase == "train":
                    loss.backward()
                    optimizer.step()

            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(
                predictions == labels
            ).item()

        epoch_loss = running_loss / dataset_sizes[phase]
        epoch_accuracy = running_corrects / dataset_sizes[phase]

        print(
            f"{phase.upper():5s} | "
            f"Loss: {epoch_loss:.4f} | "
            f"Accuracy: {epoch_accuracy * 100:.2f}%"
        )

        if phase == "val":
            scheduler.step(epoch_loss)

            # Keep the checkpoint with the lowest validation loss.
            if epoch_loss < best_val_loss:
                best_val_loss = epoch_loss
                best_val_accuracy = epoch_accuracy
                best_model_weights = copy.deepcopy(
                    model.state_dict()
                )
                epochs_without_improvement = 0

                torch.save(best_model_weights, MODEL_PATH)
                print("  Best validation model saved.")
            else:
                epochs_without_improvement += 1

    print(
        "Learning rates | "
        f"Layer4: {optimizer.param_groups[0]['lr']:.7f} | "
        f"FC: {optimizer.param_groups[1]['lr']:.7f}"
    )

    if epochs_without_improvement >= EARLY_STOPPING_PATIENCE:
        print(
            "\nEarly stopping: validation loss did not improve "
            f"for {EARLY_STOPPING_PATIENCE} consecutive epochs."
        )
        break


# --------------------------------------------------
# 9. SAVE BEST MODEL
# --------------------------------------------------

model.load_state_dict(best_model_weights)
torch.save(model.state_dict(), MODEL_PATH)

elapsed_minutes = (time.time() - start_time) / 60

print("\n" + "=" * 60)
print("TRAINING COMPLETED")
print("=" * 60)
print(f"Best validation loss: {best_val_loss:.4f}")
print(f"Best validation accuracy: {best_val_accuracy * 100:.2f}%")
print(f"Training time: {elapsed_minutes:.1f} minutes")
print(f"Model saved to: {MODEL_PATH}")
print("Class labels: 0 = REAL, 1 = FAKE")
print("=" * 60)
