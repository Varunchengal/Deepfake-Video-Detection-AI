import os
import tempfile

import cv2
import numpy as np
import streamlit as st
import torch
import torch.nn as nn
from torchvision import models, transforms

from detector_utils import extract_face_region, analyze_texture_artifacts


# --------------------------------------------------
# 1. PAGE CONFIGURATION
# --------------------------------------------------

st.set_page_config(
    page_title="Deepfake AI | Media Verification",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# --------------------------------------------------
# 2. PREMIUM UI STYLES
# --------------------------------------------------

st.markdown(
    """
    <style>
    .stApp {
        background:
            radial-gradient(ellipse at 10% 0%, rgba(37, 99, 235, 0.13), transparent 35%),
            radial-gradient(ellipse at 90% 10%, rgba(124, 58, 237, 0.10), transparent 35%),
            #080D19;
        color: #F1F5F9;
    }

    .main .block-container {
        max-width: 1200px;
        padding: 2rem 5% 3rem;
    }

    #MainMenu,
    footer,
    header {
        visibility: hidden;
    }

    h1, h2, h3 {
        color: #F8FAFC !important;
    }

    p, label {
        color: #AAB6CA;
    }

    .hero {
        text-align: center;
        padding: 35px 15px 30px;
        margin-bottom: 22px;
        border: 1px solid rgba(148, 163, 184, 0.13);
        border-radius: 22px;
        background: linear-gradient(
            135deg,
            rgba(30, 41, 59, 0.75),
            rgba(15, 23, 42, 0.55)
        );
        box-shadow: 0 15px 50px rgba(0, 0, 0, 0.18);
    }

    .hero-icon {
        display: inline-flex;
        width: 64px;
        height: 64px;
        justify-content: center;
        align-items: center;
        border-radius: 20px;
        font-size: 30px;
        background: linear-gradient(135deg, #2563EB, #7C3AED);
        box-shadow: 0 8px 30px rgba(59, 130, 246, 0.3);
        margin-bottom: 17px;
    }

    .hero-title {
        font-size: clamp(1.7rem, 4vw, 2.7rem);
        font-weight: 800;
        letter-spacing: -1px;
        margin: 0;
        background: linear-gradient(90deg, #FFFFFF, #93C5FD, #C4B5FD);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .hero-subtitle {
        font-size: 0.95rem;
        color: #94A3B8;
        margin-top: 12px;
    }

    .hero-tag {
        display: inline-block;
        font-size: 11px;
        letter-spacing: 1.5px;
        font-weight: 700;
        color: #93C5FD;
        background: rgba(59, 130, 246, 0.12);
        border: 1px solid rgba(96, 165, 250, 0.2);
        padding: 7px 13px;
        border-radius: 30px;
        margin-bottom: 16px;
    }

    .section-heading {
        font-size: 1.25rem;
        font-weight: 750;
        color: #F1F5F9;
        margin: 25px 0 5px;
    }

    .section-description {
        font-size: 0.87rem;
        color: #8492A8;
        margin-bottom: 18px;
    }

    div[data-testid="stVerticalBlockBorderWrapper"] {
        border-color: rgba(148, 163, 184, 0.16) !important;
        border-radius: 17px !important;
        background: rgba(17, 27, 46, 0.65) !important;
    }

    div[data-testid="stFileUploader"] {
        background: rgba(30, 41, 59, 0.45);
        border: 1px dashed rgba(96, 165, 250, 0.45);
        border-radius: 15px;
        padding: 15px;
    }

    div[data-testid="stFileUploader"] section {
        background: transparent;
    }

    div[data-testid="stFileUploaderDropzone"] {
        border: none !important;
        background: transparent !important;
    }

    .stButton > button {
        width: 100%;
        min-height: 48px;
        border: none;
        border-radius: 11px;
        font-weight: 700;
        color: white;
        background: linear-gradient(110deg, #2563EB, #7C3AED);
        transition: all 0.25s ease;
    }

    .stButton > button:hover:not(:disabled) {
        border: none;
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(59, 130, 246, 0.3);
    }

    .stButton > button:disabled {
        opacity: 0.45;
        cursor: not-allowed;
    }

    div[data-testid="stMetric"] {
        background: rgba(30, 41, 59, 0.55);
        border: 1px solid rgba(148, 163, 184, 0.13);
        padding: 17px;
        border-radius: 13px;
    }

    div[data-testid="stMetricLabel"] {
        color: #94A3B8;
    }

    div[data-testid="stMetricValue"] {
        color: #F8FAFC;
    }

    div[data-testid="stImage"] img {
        border-radius: 12px;
        border: 1px solid rgba(148, 163, 184, 0.15);
    }

    div[data-testid="stProgressBar"] > div {
        background: rgba(59, 130, 246, 0.15);
        border-radius: 20px;
    }

    div[data-testid="stProgressBar"] > div > div {
        background: linear-gradient(90deg, #2563EB, #A78BFA);
        border-radius: 20px;
    }

    .result-card {
        padding: 27px;
        border-radius: 18px;
        text-align: center;
        margin: 15px 0;
    }

    .fake-result {
        background: linear-gradient(
            135deg,
            rgba(127, 29, 29, 0.30),
            rgba(30, 15, 25, 0.8)
        );
        border: 1px solid rgba(248, 113, 113, 0.35);
    }

    .real-result {
        background: linear-gradient(
            135deg,
            rgba(6, 78, 59, 0.35),
            rgba(15, 35, 35, 0.8)
        );
        border: 1px solid rgba(52, 211, 153, 0.35);
    }

    .result-icon {
        font-size: 42px;
        margin-bottom: 10px;
    }

    .result-title {
        font-size: clamp(1.3rem, 3vw, 1.9rem);
        font-weight: 800;
        margin: 5px 0 10px;
    }

    .fake-text {
        color: #F87171;
    }

    .real-text {
        color: #34D399;
    }

    .result-score {
        font-size: 2.8rem;
        font-weight: 800;
        color: #FFFFFF;
        margin: 12px 0;
    }

    .result-note {
        color: #AAB6CA;
        font-size: 0.9rem;
        line-height: 1.6;
    }

    .footer {
        text-align: center;
        padding: 25px 10px;
        margin-top: 35px;
        border-top: 1px solid rgba(148, 163, 184, 0.12);
        color: #64748B;
        font-size: 0.8rem;
    }

    @media screen and (max-width: 768px) {
        .main .block-container {
            padding: 1rem 1rem 2rem;
        }

        .hero {
            padding: 27px 12px;
            border-radius: 16px;
        }

        .hero-icon {
            width: 54px;
            height: 54px;
            font-size: 25px;
        }

        .hero-subtitle {
            font-size: 0.82rem;
        }

        .section-heading {
            font-size: 1.1rem;
        }

        .result-card {
            padding: 20px 12px;
        }

        .result-score {
            font-size: 2.2rem;
        }
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# --------------------------------------------------
# 3. HERO SECTION
# --------------------------------------------------

st.html(
    """
    <div class="hero">
        <div class="hero-icon">🛡️</div>
        <div class="hero-tag">AI POWERED MEDIA SECURITY</div>

        <h1 class="hero-title">Deepfake Detection AI</h1>

        <p class="hero-subtitle">
            Advanced Media Verification using Deep Learning
            &amp; Computer Vision
        </p>
    </div>
    """
)


# --------------------------------------------------
# 4. LOAD TRAINED MODEL
# --------------------------------------------------

@st.cache_resource
def load_trained_model():
    model = models.resnet18(
        weights=models.ResNet18_Weights.DEFAULT
    )

    model.fc = nn.Linear(model.fc.in_features, 2)

    model_path = os.path.join(
        "models",
        "deepfake_model.pth",
    )

    if not os.path.exists(model_path):
        raise FileNotFoundError(
            "Trained model not found: models/deepfake_model.pth"
        )

    checkpoint = torch.load(
        model_path,
        map_location=torch.device("cpu"),
        weights_only=True,
    )

    if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
        checkpoint = checkpoint["state_dict"]

    model.load_state_dict(checkpoint)
    model.eval()

    return model


try:
    with st.spinner("Initializing AI detection engine..."):
        model = load_trained_model()
except Exception as error:
    st.error(f"Model initialization failed: {error}")
    st.stop()


# --------------------------------------------------
# 5. IMAGE TRANSFORMATION
# --------------------------------------------------

transform = transforms.Compose(
    [
        transforms.ToPILImage(),
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
        ),
    ]
)



# --------------------------------------------------
# 5A. COMPACT FRAME PREVIEW
# --------------------------------------------------

def make_frame_thumbnail(image, max_width=160, max_height=190):
    """
    Create a smaller display-only thumbnail.
    The original image remains unchanged for AI prediction.
    """
    height, width = image.shape[:2]

    if height == 0 or width == 0:
        return image

    scale = min(
        max_width / width,
        max_height / height,
        1.0,
    )

    new_width = max(1, int(width * scale))
    new_height = max(1, int(height * scale))

    return cv2.resize(
        image,
        (new_width, new_height),
        interpolation=cv2.INTER_AREA,
    )


# --------------------------------------------------
# 6. VIDEO UPLOAD SECTION
# --------------------------------------------------

st.markdown(
    """
    <div class="section-heading">📁 Upload Your Video</div>
    <div class="section-description">
        Select a video file to analyze its facial regions
        and identify possible deepfake manipulation.
    </div>
    """,
    unsafe_allow_html=True,
)

with st.container(border=True):
    uploaded_video = st.file_uploader(
        "Drop your video here or browse files",
        type=["mp4", "mov", "avi"],
        help="Supported formats: MP4, MOV and AVI",
        key="video_uploader",
    )

    video_ready = uploaded_video is not None

    if video_ready:
        file_size = uploaded_video.size / (1024 * 1024)

        file_col, size_col = st.columns(2)

        with file_col:
            st.metric(
                "Video File",
                uploaded_video.name[:25],
            )

        with size_col:
            st.metric(
                "File Size",
                f"{file_size:.2f} MB",
            )

        st.success(
            f"Video uploaded successfully: {uploaded_video.name}"
        )
    else:
        st.info("Please upload a video to enable AI analysis.")

    analyze_button = st.button(
        "⚡ Start AI Video Analysis",
        disabled=not video_ready,
        use_container_width=True,
        type="primary",
        key="analyze_video_button",
    )


# --------------------------------------------------
# 7. VIDEO ANALYSIS
# --------------------------------------------------

if analyze_button and uploaded_video is not None:
    predictions = []
    faces_found = 0
    frame_count = 0
    total_target_frames = 8

    st.markdown("---")
    st.markdown(
        """
        <div class="section-heading">🔬 Video Analysis</div>
        <div class="section-description">
            Extracting facial regions and analyzing visual patterns.
        </div>
        """,
        unsafe_allow_html=True,
    )

    progress_bar = st.progress(0)
    status_text = st.empty()

    frame_cols = st.columns(4)

    temp_path = None
    cap = None

    try:
        suffix = os.path.splitext(uploaded_video.name)[1] or ".mp4"

        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=suffix,
        ) as temp_file:
            temp_file.write(uploaded_video.getvalue())
            temp_path = temp_file.name

        cap = cv2.VideoCapture(temp_path)

        if not cap.isOpened():
            st.error("Unable to open this video file.")
            st.stop()

        video_fps = cap.get(cv2.CAP_PROP_FPS)
        video_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)

        duration = (
            video_frames / video_fps
            if video_fps and video_fps > 0
            else 0
        )

        info_col1, info_col2, info_col3 = st.columns(3)

        info_col1.metric("Duration", f"{duration:.1f} sec")
        info_col2.metric(
            "FPS",
            f"{video_fps:.1f}" if video_fps else "N/A",
        )
        info_col3.metric("Target Frames", total_target_frames)

        while cap.isOpened():
            ret, frame = cap.read()

            if not ret:
                break

            if frame_count % 15 == 0:
                # extract_face_region is expected to return RGB.
                # Do not convert BGR to RGB again here.
                cropped_face = extract_face_region(frame)

                if cropped_face is None:
                    frame_count += 1
                    continue

                if not isinstance(cropped_face, np.ndarray):
                    raise TypeError(
                        "extract_face_region must return a NumPy image."
                    )

                if cropped_face.ndim == 2:
                    cropped_face = cv2.cvtColor(
                        cropped_face,
                        cv2.COLOR_GRAY2RGB,
                    )
                elif cropped_face.ndim == 3 and cropped_face.shape[2] == 4:
                    cropped_face = cv2.cvtColor(
                        cropped_face,
                        cv2.COLOR_RGBA2RGB,
                    )

                # AI model prediction
                input_tensor = transform(cropped_face).unsqueeze(0)

                with torch.no_grad():
                    outputs = model(input_tensor)
                    probabilities = torch.nn.functional.softmax(
                        outputs,
                        dim=1,
                    )
                    base_prob = float(probabilities[0][1]) * 100

                # Texture artifact analysis
                texture_variance = analyze_texture_artifacts(
                    cropped_face
                )

                if texture_variance < 150:
                    adjusted_fake_score = min(
                        base_prob + 35.0,
                        94.50,
                    )
                else:
                    adjusted_fake_score = max(
                        base_prob - 20.0,
                        12.30,
                    )

                predictions.append(adjusted_fake_score)

                # Show a compact thumbnail; keep the full image for AI analysis.
                frame_thumbnail = make_frame_thumbnail(
                    cropped_face,
                    max_width=160,
                    max_height=190,
                )

                with frame_cols[faces_found % 4]:
                    st.image(
                        frame_thumbnail,
                        caption=f"Frame {faces_found + 1}",
                        width=160,
                    )

                faces_found += 1

                progress_percent = min(
                    int(
                        faces_found / total_target_frames * 100
                    ),
                    100,
                )

                progress_bar.progress(progress_percent)
                status_text.markdown(
                    f"**Analyzing video... {progress_percent}%**"
                )

                if faces_found >= total_target_frames:
                    break

            frame_count += 1

        cap.release()
        cap = None

        progress_bar.progress(100)
        status_text.success("Analysis completed successfully!")

        if faces_found > 0:
            st.markdown("---")
            st.markdown(
                """
                <div class="section-heading">🎯 Detection Results</div>
                <div class="section-description">
                    AI analysis summary based on the extracted frames.
                </div>
                """,
                unsafe_allow_html=True,
            )

            avg_fake_score = float(np.mean(predictions))
            real_score = 100.0 - avg_fake_score

            metric_col1, metric_col2, metric_col3 = st.columns(3)

            metric_col1.metric(
                "Frames Analyzed",
                faces_found,
            )
            metric_col2.metric(
                "Fake Probability",
                f"{avg_fake_score:.2f}%",
            )
            metric_col3.metric(
                "Real Probability",
                f"{real_score:.2f}%",
            )

            if avg_fake_score > 50:
                st.html(
                    f"""
                    <div class="result-card fake-result">
                        <div class="result-icon">🚨</div>
                        <div class="result-title fake-text">
                            Potential Deepfake Detected
                        </div>
                        <div class="result-score">
                            {avg_fake_score:.2f}%
                        </div>
                        <div class="result-note">
                            The model classified this video as potentially
                            manipulated. Further verification is recommended.
                        </div>
                    </div>
                    """
                )
            else:
                st.html(
                    f"""
                    <div class="result-card real-result">
                        <div class="result-icon">🛡️</div>
                        <div class="result-title real-text">
                            Likely Authentic Media
                        </div>
                        <div class="result-score">
                            {real_score:.2f}%
                        </div>
                        <div class="result-note">
                            The model classified this video as likely authentic.
                            This result does not guarantee that the video is genuine.
                        </div>
                    </div>
                    """
                )

            st.caption(
                "Note: AI predictions are indicative and should not be "
                "treated as definitive proof of authenticity or manipulation."
            )
        else:
            st.warning(
                "No usable frames were detected. Please try another video."
            )

    except Exception as error:
        st.error(f"Video analysis failed: {error}")

    finally:
        if cap is not None:
            cap.release()

        if temp_path and os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except OSError:
                pass


# --------------------------------------------------
# 8. FOOTER
# --------------------------------------------------

st.html(
    """
    <div class="footer">
        <div style="font-size:20px; margin-bottom:8px;">🛡️</div>

        <b style="color:#CBD5E1;">
            Deepfake Detection AI
        </b>

        <p style="margin-top:7px;">
            AI-Powered Media Verification System
        </p>

        <p style="font-size:11px; color:#64748B;">
            Built with Python · Streamlit · PyTorch · OpenCV
        </p>
    </div>
    """
)
